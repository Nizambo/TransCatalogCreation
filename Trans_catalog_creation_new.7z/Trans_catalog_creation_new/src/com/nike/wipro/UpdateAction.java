package com.nike.wipro;

import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class UpdateAction {
	
    
	
	private static final String MasterCatalog = null;

	public static boolean loginSTG(WebDriver driver){
	    driver.get("https://cdm-webapp-stg.nikecloud.net/CDM_Web/login.do");
	    driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[2]/span[2]/input")).sendKeys("njeel1");
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[3]/span[2]/input")).sendKeys("Ni#909457");		
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[4]/input")).click();
		
		return true;
	}

	public static boolean loginProd(WebDriver driver){
	    driver.get("https://cdmwebapp.nikeprd.net/CDM_Web/login.do");
	    driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[2]/span[2]/input")).sendKeys("njeel1");
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[3]/span[2]/input")).sendKeys("Ni#909457");		
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[4]/input")).click();
		
		return true;
	}

	public static void createTransCatalog(WebDriver driver, TransCatalogBean c, Logger logger){
		
		try{			
			Thread.sleep(1000);
			Select select6 = new Select(driver.findElement(By.xpath("//*[@id=\"row\"]/thead/tr/th[5]/select")));
			//*[@id="row"]/thead/tr/th[5]/select
			//*[@id="row"]/thead/tr/th[5]/select
			Thread.sleep(1000);
			select6.selectByVisibleText("Stephanie Bleckmann");//Drew Swenson");//Marcus Hiersche");//Drew Swenson"); 	//"Stephanie Bleckmann");
			Thread.sleep(1000);
			
			Select select7 = new Select(driver.findElement(By.xpath("//*[@id=\"row\"]/thead/tr/th[6]/select")));
			
			select7.selectByVisibleText("SP2022");
			
			List<WebElement> mstrCatalogHdrs=driver.findElements(By.xpath(".//*[@id='row']/tbody/tr"));
			int lenOfmstrctlgs=mstrCatalogHdrs.size();
			logger.info("length is" + lenOfmstrctlgs);
			
			/*
			Robot robot = new Robot();
	        try {
	            robot = new Robot();
	        } 
	            catch (AWTException e) {
	            e.printStackTrace();
	        }
	            robot.keyPress(KeyEvent.VK_CONTROL);
	            robot.keyPress(KeyEvent.VK_F);  
	           // robot.toString((c.getCatalogId());
	            robot.keyRelease(KeyEvent.VK_CONTROL);
	            robot.keyRelease(KeyEvent.VK_F);
	            
	            *
	            */
			
			
			
//******************************************************************************************************************************			
			
			for(int i=1;i<=lenOfmstrctlgs;i++)
			{
				String xpath="//*[@id=\"row\"]/tbody/tr["+i+"]/td[";
				//*[@id="row"]/tbody/tr[9]/td[4]
				
						String xpath2=xpath+"2]";
						String xpath4=xpath+"4]";
						String xpath1=xpath+"1]";
						//*[@id='row']/tbody/tr[3]/td[1]/div/input[1]
						
						
					//	logger.info(driver.findElement(By.xpath(xpath4)).getText());
//						System.out.println("test"+driver.findElement(By.xpath(xpath4)).getText()+"       "+(c.getCatalogId()));
				if(driver.findElement(By.xpath(xpath4)).getText().equals(c.getCatalogId()))
				{
					//System.out.println("Working");
//					Thread.sleep(8000);
					driver.findElement(By.xpath(xpath1+"/div/input[1]")).click();
					//logger.info("app : "+driver.findElement(By.xpath(xpath4)).getText() +  "     excel : "+c.getCatalogId());
					
					break;
				}
				
				
			}
//*****************************************************************************************************************************/
			
			
//************************************************Temp fixxxxxxxxxxxxxxxx****************************************************************************
//			String xpath = "//*[@id=\"row\"]/tbody/tr/td[1]/div/input[1]";
//			//*[@id="row"]/tbody/tr/td[1]/div/input[1]
//			logger.info(driver.findElement(By.xpath("//*[@id=\"row\"]/tbody/tr/td[4]")).getText()+"    excel id : "+c.getCatalogId());
//			//if((driver.findElement(By.xpath("//*[@id=\"row\"]/tbody/tr/td[4]")).getText()).equals(c.getCatalogId()) ) {
//				driver.findElement(By.xpath(xpath)).click();
//				logger.info("clickingggggggggggggggggggggggggggggggggggggggggggggg");
//				
//			//}
//			
			
//****************************************************************************************************************************
			
			
			
			
			//logger.info(" Finding the catalog ID");
		//	driver.findElement(By.xpath(".//*[@id='row']/tbody/tr/td[1]/div/input[1]")).click();
//			Thread.sleep(2000);
			driver.findElement(By.xpath(".//*[@id='manage-catalogs-form']/div/div/div[3]/table/tbody/tr[2]/td[5]/table/tbody/tr[2]/td/input")).click();
			//*[@id="manage-catalogs-form"]/div/div/div[3]/table/tbody/tr[2]/td[5]/table/tbody/tr[2]/td/input
											//*[@id="row"]/tbody/tr[1]/td[1]/div/input[1]
			//								*[@id="row"]/tbody/tr[2]/td[1]/div/input[1]
			Thread.sleep(2000);
//			logger.info(" Catalog ID found");
			
			driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[2]/td[2]/input")).clear();  //transactional catalog name clearing
			
			driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[2]/td[2]/input")).sendKeys(c.getTransCatalogName());
			
			Thread.sleep(1000);
			logger.info("CatalogTYpe is "+ c.getCatalogType());
			Select select = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[3]/td[2]/select")));
			select.selectByVisibleText(c.getCatalogType());
			Thread.sleep(1000);
			
			Select select1 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[4]/td[2]/select")));
			select1.selectByVisibleText(c.getPriceList());
			//Thread.sleep(1000);
			
			Select select2 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[5]/td[2]/select")));
			select2.selectByVisibleText(c.getCurrency());	
			
			Select select3 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[6]/td[2]/select")));
			select3.selectByVisibleText(c.getLanguage());
			
			Select select4 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[7]/td[2]/select")));
			select4.selectByVisibleText(c.getOrganization());
//			Thread.sleep(1000);
			
			Select select5 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[4]/table/tbody/tr[6]/td[2]/select")));
			select5.selectByVisibleText(c.getPDFformat());
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("html/body/div[4]/div[2]/div/input[2]")).click();
			
			Thread.sleep(2000);
			
			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[2]/td[1]/input")).click();	//sbleck
			//*[@id="searchRow"]/tbody/tr[2]/td[1]/input
		Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"searchRow\"]/tbody/tr[3]/td[1]/input")).click();  //mhiers
			//*[@id="searchRow"]/tbody/tr[3]/td[1]/input
			Thread.sleep(1000);
			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[4]/td[1]/input")).click();   //mleve1
			//*[@id="searchRow"]/tbody/tr[4]/td[1]/input
			Thread.sleep(1000);
			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[5]/td[1]/input")).click();   //dswens
			//*[@id="searchRow"]/tbody/tr[5]/td[1]/input
			Thread.sleep(1000);
			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[6]/td[1]/input")).click();   //btsuma
			
//			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[6]/td[1]/input")).click();   //btsuma
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("html/body/div[5]/form/div[2]/div/div[3]/div/table/tbody/tr/td/table/tbody/tr[2]/td/input")).click();
			//add users button

			Thread.sleep(1000);
			
			driver.findElement(By.xpath("//*[@id=\"row1\"]/tbody/tr[2]/td[1]/div/input")).click();  //ownr sbleck

			//*[@id="row1"]/tbody/tr[2]/td[1]/div/input   // owner sbleck
			//*[@id="row1"]/tbody/tr[3]/td[1]/div/input	  //owner marcus hiersche
			//*[@id="row1"]/tbody/tr[4]/td[1]/div/input   //ownr michelle levesque mleve1
			//*[@id="row1"]/tbody/tr[5]/td[1]/div/input   //owner drew
			//*[@id="row1"]/tbody/tr[6]/td[1]/div/input   //owner btsuma
			// owner dswenseclips
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("html/body/div[5]/form/div[1]/div/div[3]/div/table/tbody/tr/td/table/tbody/tr[2]/td[1]/input")).click();
			//make owner button
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("html/body/div[6]/form/center/div/input[2]")).click();      //Submit button
			Thread.sleep(2000);
			driver.findElement(By.xpath(".//*[@id='header']/h2/a/img")).click();        //CDM image for  switching to home page
//			Thread.sleep(3000);
			//*[@id="searchRow"]/tbody/tr[4]/td[1]/input
			//*[@id="searchRow"]/tbody/tr[2]/td[1]/input
			//*[@id="searchRow"]/tbody/tr[5]/td[1]/input
			//*[@id="row1"]/tbody/tr[2]/td[1]/div/input
			////*[@id='row1']/tbody/tr[2]/td[1]/div/input")).click(); sbleck
			//*[@id='row1']/tbody/tr[3]/td[1]/div/input")).click(); drew
			//*[@id='row1']/tbody/tr[4]/td[1]/div/input")).click(); tsuma
			
			
		}   	
		//*[@id="row1"]/tbody/tr[4]/td[1]/div/input
						
	
		catch( Exception f){
			f.printStackTrace();
			
		}
	}

		






	
	}
	
			
//		try{			
//			driver.findElement(By.xpath(".//*[@id='row']/thead/tr/th[5]/select")).sendKeys('Marcus Hiersche');
//			Thread.sleep(3000);
//			
//			driver.findElement(By.xpath(".//*[@id='row']/tbody/tr/td[1]/div/input[1]")).click();
//			//Thread.sleep(1000);
//			driver.findElement(By.xpath(".//*[@id='manage-catalogs-form']/div/div/div[3]/table/tbody/tr[2]/td[5]/table/tbody/tr[2]/td/input")).click();
//			Thread.sleep(1000);
//			driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[2]/td[2]/input")).clear();
//			driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[2]/td[2]/input")).sendKeys(c.getTransCatalogName());
//			
//			logger.info("CatalogTYpe is "+ c.getCatalogType());
//			Select select = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[3]/td[2]/select")));
//			select.selectByVisibleText(c.getCatalogType());
//			Thread.sleep(1000);
//			Select select1 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[4]/td[2]/select")));
//			select1.selectByVisibleText(c.getPriceList());
//			Thread.sleep(1000);
//			Select select2 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[5]/td[2]/select")));
//			select2.selectByVisibleText(c.getCurrency());
//			Thread.sleep(1000);
//			Select select3 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[6]/td[2]/select")));
//			select3.selectByVisibleText(c.getLanguage());
//			Thread.sleep(1000);
//			Select select4 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[2]/table/tbody/tr[7]/td[2]/select")));
//			select4.selectByVisibleText(c.getOrganization());
//			Thread.sleep(1000);
//			Select select5 = new Select(driver.findElement(By.xpath("html/body/div[4]/div[1]/form/div[4]/table/tbody/tr[6]/td[2]/select")));
//			select5.selectByVisibleText(c.getPDFformat());
//			driver.findElement(By.xpath("html/body/div[4]/div[2]/div/input[2]")).click();
//			Thread.sleep(2000);
//			
//			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[3]/td[1]/input")).click();		
//			Thread.sleep(1000);
//			driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr[5]/td[1]/input")).click();
//			Thread.sleep(1000);
//			driver.findElement(By.xpath("html/body/div[5]/form/div[2]/div/div[3]/div/table/tbody/tr/td/table/tbody/tr[2]/td/input")).click();
//			Thread.sleep(1000);
//			driver.findElement(By.xpath(".//*[@id='row1']/tbody/tr[3]/td[1]/div/input")).click();
//			Thread.sleep(1000);
//			driver.findElement(By.xpath("html/body/div[5]/form/div[1]/div/div[3]/div/table/tbody/tr/td/table/tbody/tr[2]/td[1]/input")).click();
//			Thread.sleep(1000);
//			driver.findElement(By.xpath("html/body/div[6]/form/center/div/input[2]")).click();
//			driver.findElement(By.xpath(".//*[@id='header']/h2/a/img")).click();
//			Thread.sleep(3000);
//			
//		}   	
//	            	
//						
//	
//		catch( Exception f){
//			f.printStackTrace();
//			
//		}
//	}
//}
//		





