package com.nike.wipro;

public class TransCatalogBean {
	
	private String CatalogId;
	private String TransCatalogName;
	private String CatalogType;
	private String PriceList;
	private String Currency;
	private String Language;
	private String Organization;
	private String PDFformat;
	private String Membership;
	private String Membership2;
	private String Membership3;
	private String Membership4;
	//private String Membership5;
	public String getCatalogId() {
		return CatalogId;
	}
	public void setCatalogId(String catalogId) {
		CatalogId = catalogId;
	}
	public String getTransCatalogName() {
		return TransCatalogName;
	}
	public void setTransCatalogName(String transCatalogName) {
		TransCatalogName = transCatalogName;
	}
	public String getCatalogType() {
		return CatalogType;
	}
	public void setCatalogType(String catalogType) {
		CatalogType = catalogType;
	}
	public String getPriceList() {
		return PriceList;
	}
	public void setPriceList(String priceList) {
		PriceList = priceList;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public String getLanguage() {
		return Language;
	}
	public void setLanguage(String language) {
		Language = language;
	}
	public String getOrganization() {
		return Organization;
	}
	public void setOrganization(String organization) {
		Organization = organization;
	}
	public String getPDFformat() {
		return PDFformat;
	}
	public void setPDFformat(String pDFformat) {
		PDFformat = pDFformat;
	}
	public String getMembership() {
		return Membership;
	}
	public void setMembership(String membership) {
		Membership = membership;
	}
	public String getMembership2() {
		return Membership2;
	}
	public void setMembership2(String membership2) {
		Membership2 = membership2;
	}
	public String getMembership3() {
		return Membership3;
	}
	public void setMembership3(String membership3) {
		Membership3 = membership3;
	}
	public String getMembership4() {
		return Membership4;
	}
	public void setMembership4(String membership4) {
		Membership4 = membership4;
	}
	/*public String getMembership5() {
		return Membership5;
	}
	public void setMembership5(String membership5) {
		Membership5 = membership5;
	}

	*/

}
