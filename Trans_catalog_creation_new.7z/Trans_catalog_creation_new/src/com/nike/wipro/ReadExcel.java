package com.nike.wipro;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.logging.Logger;

//import com.gargoylesoftware.htmlunit.javascript.host.Set;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcel {
	public static List<TransCatalogBean> readExcel() throws BiffException,IOException {
	
		Logger  logger = Logger.getLogger("MyLog");
		//String FilePath = "C:\\Selenium\\Excel\\TestCase.xlsx";
		FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Trans_Catalog1.xls"));
		Workbook wb = Workbook.getWorkbook(fs);
		List<TransCatalogBean> catalogList=new ArrayList<TransCatalogBean>();
		LinkedHashSet catalog_id = new LinkedHashSet();
	//	LinkedHashSet catalog_type= new LinkedHashSet();
		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		for (int row = 0; row < totalNoOfRows; row++) {
			
			if(row==0)
			{
				continue;
			}
			TransCatalogBean c=new TransCatalogBean();
			for (int col = 0; col < totalNoOfCols; col++)
				{
				System.out.print(sh.getCell(col, row).getContents() + "\t");
				catalog_id.add(sh.getCell(col, row).getContents());
				
				
				
				if(col==0)
				{
					
					c.setCatalogId(sh.getCell(col, row).getContents());
					
				}

				if(col==1)
				{
					c.setTransCatalogName(sh.getCell(col, row).getContents());
				}
				
				if(col==2)
				{
					c.setCatalogType(sh.getCell(col, row).getContents());
				}
				
				if(col==3)
				{
					c.setPriceList(sh.getCell(col, row).getContents());
				}
				if(col==4)
				{
					c.setCurrency(sh.getCell(col, row).getContents());
				}
				if(col==5)
				{
					c.setLanguage(sh.getCell(col, row).getContents());
				}
				if(col==6)
				{
					c.setOrganization(sh.getCell(col, row).getContents());
				}
				if(col==7)
				{
					c.setPDFformat(sh.getCell(col, row).getContents());
				}
				if(col==8)
				{
					c.setMembership(sh.getCell(col, row).getContents());
				}
				if(col==9)
				{
					c.setMembership2(sh.getCell(col, row).getContents());
				}
				if(col==10)
				{
					c.setMembership3(sh.getCell(col, row).getContents());
				}
				if(col==11)
				{
					c.setMembership4(sh.getCell(col, row).getContents());
				}
				/*if(col==12)
				{
					c.setMembership5(sh.getCell(col, row).getContents());
				}
				*/
				
			//	catalog_type.add(sh.getCell(col+1,row).getContents());
			//	System.out.print(sh.getCell(col+1, row).getContents() + "\t");
			}
			catalogList.add(c);
		}
		return catalogList;
		
				
		
				
	}
	
}
